package com.it.service;

import com.it.model.User;

public interface UserService {

	public User findById(int id);

	public User findBySso(String sso);

}