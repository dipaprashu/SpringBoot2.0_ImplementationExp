package com.it.client;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.it.model.User;

public class UserRestClient {
	
	private static final String REST_SERVICE_URI="http://localhost:8084/SpringBootRestApi/users";

	/* GET */
	@SuppressWarnings("unchecked")
	public static void listAllUsers(){
		
        System.out.println("Testing listAllUsers API-----------");
        RestTemplate  restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> usersMap = restTemplate.getForObject(REST_SERVICE_URI+"/list/", List.class);
        if(usersMap!=null){
            for(LinkedHashMap<String, Object> map : usersMap){
                System.out.println("User : id="+map.get("id")+", Name="+map.get("name")+", Age="+map.get("age")+", Salary="+map.get("salary"));
            }
        }else{
            System.out.println("No user exist----------");
        }
        
    }//listAllUsers()
	
	 /* DELETE */
    public static void deleteAllUsers() {
       
    	System.out.println("Testing all delete Users API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/delall/");
        
    }//deleteAllUsers()
    
    /* GET */
    public static void getUser(){
    	
        System.out.println("Testing getUser API----------");
        RestTemplate restTemplate = new RestTemplate();
        User user = restTemplate.getForObject(REST_SERVICE_URI+"/user/1", User.class);
        System.out.println("ID-->"+user.getId());
        System.out.println("Name-->"+user.getName());
        System.out.println("Age-->"+user.getAge());
        System.out.println("Salary-->"+user.getSalary());
        
    }//getUser()
    
    /* POST */
    public static void createUser() {
    	
        System.out.println("Testing create User API----------");
        RestTemplate restTemplate = new RestTemplate();
        User user = new User(0,"Sudhanhsu",23,13498);
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI+"/save/", user, User.class);
        System.out.println("Location : "+uri.toASCIIString());
        
    }//createUser()
    
    /* PUT */
    public static void updateUser() {
     
    	System.out.println("Testing update User API----------");
        RestTemplate restTemplate = new RestTemplate();
        User user  = new User(1,"Tomy",33, 70000);
        restTemplate.put(REST_SERVICE_URI+"/update/1", user);
        System.out.println(user);
        
    }//updateUser()
    
    /* DELETE */
    public static void deleteUser() {
    	
        System.out.println("Testing delete User API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/delete/5");
        
    }//deleteUser()
    
}//class
