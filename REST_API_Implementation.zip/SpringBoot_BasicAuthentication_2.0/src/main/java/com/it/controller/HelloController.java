package com.it.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@RequestMapping("/hello")
    @ResponseBody
    public String sayHello(){
		System.out.println("Hitting the controller----->");
        return "<h2>Hello sudhanshu.. !</h2>";
    }

}//class
