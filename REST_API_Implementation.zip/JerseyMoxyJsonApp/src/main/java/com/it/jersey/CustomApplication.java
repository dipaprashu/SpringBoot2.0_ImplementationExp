package com.it.jersey;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.it.moxy.JsonMoxyConfigurationContextResolver;
import com.it.resource.JerseyService;

public class CustomApplication extends Application {

	@Override
	public Set<Class<?>> getClasses() {

		Set<Class<?>> resources = new HashSet<>();
		// register REST modules
		resources.add(JerseyService.class);
		// Manually adding MOXyJSONFeature
		resources.add(org.glassfish.jersey.moxy.json.MoxyJsonFeature.class);
		// Configure Moxy behavior
		resources.add(JsonMoxyConfigurationContextResolver.class);
		return resources;
	}

}// class
