/**
 * 
 */
package com.it.model;

import java.io.Serializable;

/**
 * @author Sudhanshu
 *
 */
public class Employee implements Serializable {

	private static final long serialVersionUID=122L;
	private Integer id;
	private String name;

	public Employee() {
		
		// no-parameter constructor
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

	public Employee(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

}// class
