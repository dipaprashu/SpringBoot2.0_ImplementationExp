package com.it.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

@Path("/{hello : (?i)hello}")
public class MyResource {
	
	@GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response getIt() {
		return Response.ok().entity("Got it!").cookie(new NewCookie("cookieResponse", "cookieValueInReturn")).build();
    }

}//class
