package com.it.jersey;

import org.glassfish.jersey.server.ResourceConfig;
import com.it.resource.GsonMessageBodyHandler;

public class CustomApplication extends ResourceConfig {
	public CustomApplication() {
		packages("com.it.jersey");
		//register(LoggingFilter.class);
		register(GsonMessageBodyHandler.class);
	}

}// class