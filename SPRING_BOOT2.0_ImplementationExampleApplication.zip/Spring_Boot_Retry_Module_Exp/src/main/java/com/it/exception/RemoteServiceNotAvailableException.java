/**
 * 
 */
package com.it.exception;

/**
 * @author Sudhanshu
 *
 */
public class RemoteServiceNotAvailableException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public RemoteServiceNotAvailableException(String msg) {
		super(msg);
	}

	public RemoteServiceNotAvailableException(String msg, Exception exception) {
		super(msg, exception);
	}

}//class
