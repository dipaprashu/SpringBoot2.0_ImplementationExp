package com.example.demo;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.it.model.Employee;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class SpringBootRestApiJunitTestingExpApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	int randomServerPort;
	

	@SuppressWarnings("deprecation")
	@Test
	public void testAddEmployeeSuccess() throws URISyntaxException {

		final String baseUrl = "http://localhost:" + randomServerPort + "/employees/";
		URI uri = new URI(baseUrl);
		Employee employee = new Employee(null, "Adam", "Gilly", "test@email.com");

		HttpHeaders headers = new HttpHeaders();
		headers.set("X-COM-PERSIST", "true");
		HttpEntity<Employee> request = new HttpEntity<>(employee, headers);
		ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
		// Verify request succeed
		Assert.assertEquals(201, result.getStatusCodeValue());

	}// testAddEmployeeSuccess()

	@Test
	public void testAddEmployeeMissingHeader() throws URISyntaxException {
		
		final String baseUrl = "http://localhost:" + randomServerPort + "/employees/";
		URI uri = new URI(baseUrl);
		Employee employee = new Employee(null, "subham", "Gill", "test@email.com");

		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Employee> request = new HttpEntity<>(employee, headers);
		ResponseEntity<String> result = this.restTemplate.postForEntity(uri, request, String.class);
		// Verify bad request and missing header
		Assert.assertEquals(400, result.getStatusCodeValue());
		Assert.assertEquals(true, result.getBody().contains("Missing request header"));

	}// testAddEmployeeMissingHeader()
	
	@Test
	public void testGetEmployeeListSuccess() throws URISyntaxException
	{
		//Second way to get RestTemplate Method
		//Create RestTemplate class Object
		RestTemplate restTemplate=new RestTemplate();
	    final String baseUrl = "http://localhost:" + randomServerPort + "/employees/list";
	    URI uri = new URI(baseUrl);
	 
	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	    //Verify request succeed
	    Assert.assertEquals(200, result.getStatusCodeValue());
	    Assert.assertEquals(false, result.getBody().contains("employeeList"));
	    
	}//testGetEmployeeListSuccess()


}// class
