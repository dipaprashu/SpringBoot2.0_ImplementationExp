package com.example.demo;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBootAutoconfigurationApplication {

	public static void main(String[] args) {
	
		ApplicationContext  ctx=SpringApplication.run(SpringBootAutoconfigurationApplication.class, args);
		String[] beans=ctx.getBeanDefinitionNames();
		Arrays.sort(beans);
		for(String bean:beans) {
			System.out.println(bean);
		}
		
	}//main
	
}//class
