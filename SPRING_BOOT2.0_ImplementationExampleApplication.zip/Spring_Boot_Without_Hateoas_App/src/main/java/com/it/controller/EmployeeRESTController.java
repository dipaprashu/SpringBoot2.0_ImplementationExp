package com.it.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.it.report.EmployeeReport;
import com.it.repository.EmployeeDB;
import com.it.vo.EmployeeListVO;
import com.it.vo.EmployeeVO;

@RestController
public class EmployeeRESTController {

	@RequestMapping(value = "/employees")
	public EmployeeListVO getAllEmployees() {
		
		EmployeeListVO employeesList = new EmployeeListVO();

		//for (EmployeeVO employee : EmployeeDB.getEmployeeList()) {
			employeesList.setEmployees(EmployeeDB.getEmployeeList());
		//}

		return employeesList;
		
	}//getAllEmployees()

	@RequestMapping(value = "/employees/{id}")
	public ResponseEntity<EmployeeVO> getEmployeeById(@PathVariable("id") int id) {
		
		if (id <= 3) {
			EmployeeVO employee = EmployeeDB.getEmployeeList().get(id - 1);
			return new ResponseEntity<>(employee, HttpStatus.OK);
		}
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}//getEmployeeById()

	@RequestMapping(value = "/employees/{id}/report")
	public ResponseEntity<EmployeeReport> getReportByEmployeeById(@PathVariable("id") int id) {
		
		return null;
		
	}//getEmployeeById()
	
}//class