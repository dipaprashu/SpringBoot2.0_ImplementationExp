package com.example.demo;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;

import com.it.model.Employee;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class SpringBootRestApiApplicationTests {
	
	@LocalServerPort
	int randomServerPort;
	
	@Test
	public void testAddEmployeeWithoutHeader_success() throws URISyntaxException
	{
	    RestTemplate restTemplate = new RestTemplate();
	     
	    final String baseUrl = "http://localhost:"+randomServerPort+"/employees/";
	    URI uri = new URI(baseUrl);
	     
	    Employee employee = new Employee(null, "Santi", "Gill", "santi.g@email.com");
	    ResponseEntity<String> result = restTemplate.postForEntity(uri, employee, String.class);
	    //Verify request succeed
	    Assert.assertEquals(201, result.getStatusCodeValue());
	    
	}//testAddEmployeeWithoutHeader_success()
	
	@Test
	public void testGetEmployeeListSuccess() throws URISyntaxException
	{
		//Second way to get RestTemplate Method
		//Create RestTemplate class Object
		RestTemplate restTemplate=new RestTemplate();
	    final String baseUrl = "http://localhost:" + randomServerPort + "/employees/list";
	    URI uri = new URI(baseUrl);
	 
	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
	    //Verify request succeed
	    Assert.assertEquals(200, result.getStatusCodeValue());
	    Assert.assertEquals(false, result.getBody().contains("employeeList"));
	    
	}//testGetEmployeeListSuccess()

}//class
