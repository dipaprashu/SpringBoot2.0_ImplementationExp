package com.it.report;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "employee-report")
public class EmployeeReport implements Serializable {

	private static final long serialVersionUID = 1L;

}//class