package com.it.model;

public class ISBN {

	private String isbn;

	public ISBN(String isbn) {
	        this.isbn = isbn;
	    }

	public String getIsbn() {
		return isbn;
	}

	public String getDisplayValue() {
		return isbn;
	}

}// class
