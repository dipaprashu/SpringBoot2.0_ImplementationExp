package com.it.editor;

import java.beans.PropertyEditorSupport;

import org.springframework.util.StringUtils;

import com.it.model.ISBN;

public class IsbnEditor extends PropertyEditorSupport {
	
	  @Override
	    public void setAsText(String text) throws IllegalArgumentException {
	        if (StringUtils.hasText(text)) {
	            setValue(new ISBN(text.trim()));
	        } else {
	            setValue(null);
	        }
	    }
	 
	    @Override
	    public String getAsText() {
	    	ISBN isbn = (ISBN) getValue();
	        if (isbn != null) {
	            return isbn.getIsbn();
	        } else {
	            return "";
	        }
	    }

}//class
