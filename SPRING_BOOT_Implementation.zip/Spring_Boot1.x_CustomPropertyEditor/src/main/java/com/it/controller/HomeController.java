package com.it.controller;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.it.editor.IsbnEditor;
import com.it.model.ISBN;

@Controller
public class HomeController {
	
	private final Log LOGGER = LogFactory.getLog(this.getClass());
	 
    @RequestMapping(value = "/books/{isbn}", method = RequestMethod.GET)
    public String getBook(@PathVariable ISBN isbn, Map<String, Object> model)
    {
        LOGGER.info("You searched for book with ISBN :: " + isbn.getIsbn());
        model.put("isbn", isbn);
        
        return "index";
    }
     
    @InitBinder
    public void initBinder(WebDataBinder binder) {
      binder.registerCustomEditor(ISBN.class, new IsbnEditor());
    }
    

}//class
