/**
 * 
 */
package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.it.retry.BackendAdapter;

/**
 * @author Sudhanshu
 *
 */
@RestController
public class MyRestController {
	
	@Autowired
	private BackendAdapter backendAdapter;

	@GetMapping("/retry")
	@ExceptionHandler({ Exception.class })
	public String validateSPringRetryCapability(@RequestParam(required = false) boolean simulateretry,
			
		@RequestParam(required = false) boolean simulateretryfallback) {
		return backendAdapter.getBackendResponse(simulateretry, simulateretryfallback);
		
	}//validateSPringRetryCapability()

}//class
