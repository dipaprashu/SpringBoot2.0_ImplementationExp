package com.it.controller;


import org.springframework.hateoas.Link;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.it.repository.EmployeeDB;
import com.it.vo.EmployeeListVO;
import com.it.vo.EmployeeVO;

@RestController
public class EmployeeRESTController {

	@RequestMapping(value = "/employees")
	public EmployeeListVO getAllEmployees()
	{
	    EmployeeListVO employeesList  = new EmployeeListVO();
	 
	    for (EmployeeVO employee : EmployeeDB.getEmployeeList())
	    {
	        //Adding self link employee 'singular' resource
	        Link link = ControllerLinkBuilder
	                .linkTo(EmployeeRESTController.class)
	                .slash(employee.getEmployeeId())
	                .withSelfRel();
	 
	        //Add link to singular resource
	        employee.add(link);
	         
	      //Adding method link employee 'singular' resource
	        ResponseEntity<EmployeeVO> methodLinkBuilder = ControllerLinkBuilder
	                .methodOn(EmployeeRESTController.class).getEmployeeById(employee.getEmployeeId());
	        Link reportLink = ControllerLinkBuilder
	                .linkTo(methodLinkBuilder)
	                .withRel("employee-report");
	 
	        //Add link to singular resource
	        employee.add(reportLink);
	   
	        employeesList.getEmployees().add(employee);
	    }
	     
	    //Adding self link employee collection resource
	    Link selfLink = ControllerLinkBuilder
	            .linkTo(ControllerLinkBuilder
	            .methodOn(EmployeeRESTController.class).getAllEmployees())
	            .withSelfRel();
	 
	    //Add link to collection resource
	    employeesList.add(selfLink);
	      
	    return employeesList;
	}

	@RequestMapping(value = "/employees/{id}")
	public ResponseEntity<EmployeeVO> getEmployeeById (@PathVariable("id") int id)
	{
	    if (id <= 3) {
	        EmployeeVO employee = EmployeeDB.getEmployeeList().get(id-1);
	         
	        //Self link
	        Link selfLink = ControllerLinkBuilder
	                .linkTo(EmployeeRESTController.class)
	                .slash(employee.getEmployeeId())
	                .withSelfRel();
	         
	        //Method link
	        Link reportLink = ControllerLinkBuilder
	                .linkTo(ControllerLinkBuilder.methodOn(EmployeeRESTController.class)
	                .getEmployeeById(employee.getEmployeeId()))
	                .withRel("report");
	         
	        employee.add(selfLink);
	        employee.add(reportLink);
	        return new ResponseEntity<>(employee, HttpStatus.OK);
	    }
	    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
}//class