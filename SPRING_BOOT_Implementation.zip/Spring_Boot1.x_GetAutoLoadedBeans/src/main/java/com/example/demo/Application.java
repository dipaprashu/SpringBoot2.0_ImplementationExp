package com.example.demo;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctx=null;
		ctx=SpringApplication.run(Application.class, args);
		String name[]=ctx.getBeanDefinitionNames();
		Arrays.sort(name);
		for(String bean:name) {
			System.out.println("Autouploaded beans are--->"+bean);
			System.out.println("Get Bean class name--->"+ctx.getBean(bean).getClass());
		}
	}
	
}//class