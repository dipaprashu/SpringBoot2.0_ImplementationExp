/**
 * 
 */
package com.it.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.it.exception.RecordNotFoundException;
import com.it.model.Employee;
import com.it.model.Employees;
import com.it.repository.EmployeeDAOImpl;
import com.it.service.EmployeeServiceImpl;

/**
 * @author Sudhanshu
 *
 */
@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeServiceImpl employeeServiceImpl;
	@Autowired
	private EmployeeDAOImpl employeeDAOImpl;

	@GetMapping(value = "/list", produces = "application/json")
	public Employees getEmployees() {
		return employeeServiceImpl.getAllEmployeesList();
	}

	@PostMapping(path = "/", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Employee> addEmployee(
			@RequestHeader(name = "X-COM-PERSIST", required = true) String headerPersist,
			@RequestHeader(name = "X-COM-LOCATION", required = false, defaultValue = "ASIA") String headerLocation,
			@RequestBody Employee employee) throws Exception {
		// Generate resource id
		Integer id = employeeDAOImpl.getAllEmployeesList().getEmployeesList().size() + 1;
		employee.setEmployeeId(id);

		// add resource
		employeeServiceImpl.addEmployees(employee);

		// Create resource location
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(employee.getEmployeeId())
				.toUri();

		// Send location in response
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping(value = "/employees/{id}")
	public ResponseEntity<Object> getEmployeeById (@PathVariable("id") int id)
	{
	    Employee employee = employeeDAOImpl.getEmployeeById(id);
	     
	    if(employee == null) {
	         throw new RecordNotFoundException("Invalid employee id : " + id);
	    }
	    return new ResponseEntity<>(employee, HttpStatus.OK);
	}

}// class
