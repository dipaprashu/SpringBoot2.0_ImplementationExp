package com.it.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.it.model.Employee;

@RestController
public class EmployeeController {
	
	@RequestMapping("/")
	public List<Employee> getEmployee(){
		
		List<Employee> employeeList=new ArrayList<>();
		employeeList.add(new Employee(1,"Sudhanshu","Kumar","shekharsudhanshu@gmail.com"));
		employeeList.add(new Employee(2,"Subham","Mishra","subhmishra@gmail.com"));
		employeeList.add(new Employee(3,"Suman","Jha","jhasuman@gmail.com"));
		employeeList.add(new Employee(4,"Raja","Ram","ramraja@gmail.com"));
		return employeeList;
	}

}//class
