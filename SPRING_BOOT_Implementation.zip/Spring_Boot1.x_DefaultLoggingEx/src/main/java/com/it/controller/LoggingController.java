package com.it.controller;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoggingController {

	private final Log logger=LogFactory.getLog(LoggingController.class);
	@RequestMapping("/")
	public String home(Map<String, Object> model) {

		logger.debug("This is a debug message");
		logger.info("This is an info message");
		logger.warn("This is a warn message");
		logger.error("This is an error message");

		model.put("message", "HowToDoInJava Reader !!");
		return "index";
	}
}
