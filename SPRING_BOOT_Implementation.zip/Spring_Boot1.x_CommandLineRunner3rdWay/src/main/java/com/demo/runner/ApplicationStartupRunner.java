package com.demo.runner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class ApplicationStartupRunner implements CommandLineRunner {

	private final Log logger=LogFactory.getLog(ApplicationStartupRunner.class);
	@Override
	public void run(String... args) throws Exception {
		logger.info("Application Started !!");
	}

}//class
