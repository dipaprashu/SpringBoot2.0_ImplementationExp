package com.demo.runner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(3)
public class ApplicationStartupRunner2 implements CommandLineRunner {

	private final Log logger=LogFactory.getLog(ApplicationStartupRunner2.class);
	@Override
	public void run(String... args) throws Exception {
		logger.info("ApplicationStartupRunnerTwo run method Started !!");
	}

}//class
