package com.demo.runner;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class ApplicationStartupRunner3 implements CommandLineRunner {

	private final Log logger=LogFactory.getLog(ApplicationStartupRunner3.class);
	@Override
	public void run(String... args) throws Exception {
		logger.info("ApplicationStartupRunnerThree run method Started !!");
	}

}//class
