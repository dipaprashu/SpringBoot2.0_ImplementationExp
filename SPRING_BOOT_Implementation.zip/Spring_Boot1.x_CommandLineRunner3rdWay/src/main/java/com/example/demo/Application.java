package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.demo.runner.ApplicationStartupRunner;
import com.demo.runner.ApplicationStartupRunner2;
import com.demo.runner.ApplicationStartupRunner3;

@SpringBootApplication
public class Application extends ServletInitializer{

	public static void main(String[] args) throws Exception {
		SpringApplication.run(Application.class, args);
	}

	//Here configure the multiple Command Runner
	@Bean
    public ApplicationStartupRunner schedulerRunner() {
        return new ApplicationStartupRunner();
    }
	
	@Bean
    public ApplicationStartupRunner2 schedulerRunner2() {
        return new ApplicationStartupRunner2();
    }
	
	@Bean
    public ApplicationStartupRunner3 schedulerRunner3() {
        return new ApplicationStartupRunner3();
    }
	
}//class
