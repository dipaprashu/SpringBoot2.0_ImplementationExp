/**
 * 
 */
package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.EmployeeDAOImpl;
import com.it.model.Employee;
import com.it.model.Employees;

/**
 * @author Sudhanshu
 *
 */
@Service
public class EmployeeServiceImpl {

	@Autowired
	private EmployeeDAOImpl employeeDaoImpl;

	public Employees getAllEmployeesList() {
		return employeeDaoImpl.getAllEmployeesList();
	}

	public void addEmployees(Employee employee) {
		employeeDaoImpl.addEmployees(employee);
	}

}// class
