/**
 * 
 */
package com.it.dao;

import org.springframework.stereotype.Repository;

import com.it.model.Employee;
import com.it.model.Employees;

/**
 * @author Sudhanshu
 *
 */
@Repository
public class EmployeeDAOImpl {
	
	private static Employees list = new Employees();

	 static
	    {
	        list.getEmployeesList().add(new Employee(1, "Lokesh", "Gupta", "howtodoinjava@gmail.com"));
	        list.getEmployeesList().add(new Employee(2, "Alex", "Kolenchiskey", "abc@gmail.com"));
	        list.getEmployeesList().add(new Employee(3, "David", "Kameron", "titanic@gmail.com"));
	    }
	 
	 public Employees getAllEmployeesList() {
		 return list;
	 }
	 
	 public void addEmployees(Employee employee) {
		 list.getEmployeesList().add(employee);
	 }
}//class
