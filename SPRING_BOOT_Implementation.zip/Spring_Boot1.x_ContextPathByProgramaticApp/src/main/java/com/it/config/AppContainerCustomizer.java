package com.it.config;

import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.stereotype.Component;

@Component
public class AppContainerCustomizer implements EmbeddedServletContainerCustomizer{
	
	 @Override
	    public void customize(ConfigurableEmbeddedServletContainer container) {
	 
	        container.setPort(8089);
	        container.setContextPath("/home");
	 
	    }	

}//class
