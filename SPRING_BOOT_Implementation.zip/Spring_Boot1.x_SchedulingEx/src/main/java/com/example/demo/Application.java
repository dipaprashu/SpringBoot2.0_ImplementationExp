package com.example.demo;

import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfiguration;

@SpringBootApplication
//Enable Scheduling 1st Way 
@EnableScheduling
//Enable Scheduling 2nd Way
//@Import(SchedulingConfiguration.class)
public class Application {

	private static final Log logger=LogFactory.getLog(Application.class);
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	//Schedule task with fixed rate
	@Scheduled(initialDelay = 1000, fixedRate = 10000)
	public void run() {
	    logger.info("Current time is :: " + Calendar.getInstance().getTime());
	}
	
	//Schedule task with Fixed Delay
	@Scheduled(fixedDelay = 10000)
	public void run1() {
	    logger.info("Current-Delay time is :: " + Calendar.getInstance().getTime());
	}
	
	//
	@Scheduled(cron = "0 10 10 10 * ?")
	public void run2() {
	    logger.info("Current-Crons time is :: " + Calendar.getInstance().getTime());
	}
	
}//class
