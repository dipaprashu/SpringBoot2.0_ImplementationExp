package com.it.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.it.model.Employee;
import com.it.model.EmployeeService;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "EmployeeResource")
@Path("/Employees")
public class EmployeeResource {

	private static Map<Integer, Employee> DB = new HashMap<>();

	@Path("/list")
	@Produces("application/json")
	@GET
	public EmployeeService getAllEmployee() {

		EmployeeService empService = new EmployeeService();
		empService.setEmployeeList(new ArrayList<>(DB.values()));
		return empService;

	}// getAllEmployee()

	@POST
	@Consumes("application/json")
	@Path("/save")
	public Response createUser(Employee emp) throws URISyntaxException {

		if (emp.getFirstName() == null || emp.getLastName() == null) {
			return Response.status(400).entity("Please provide all mandatory inputs").build();
		}
		emp.setId(DB.values().size() + 1);
		emp.setUri("/user-management/" + emp.getId());
		DB.put(emp.getId(), emp);
		return Response.status(201).contentLocation(new URI(emp.getUri())).build();

	}// createUser()

	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Response getUserById(@PathParam("id") int id) throws URISyntaxException {

		Employee emp = DB.get(id);
		if (emp == null) {
			return Response.status(404).build();
		}
		return Response.status(200).entity(emp).contentLocation(new URI("/user-management/" + id)).build();

	}// getUserById

	@PUT
	@Path("/{id}")
	@Consumes("application/json")
	@Produces("application/json")
	public Response updateUser(@PathParam("id") int id, Employee emp) throws URISyntaxException {
		Employee temp = DB.get(id);
		if (emp == null) {
			return Response.status(404).build();
		}
		temp.setFirstName(emp.getFirstName());
		temp.setLastName(emp.getLastName());
		DB.put(temp.getId(), temp);
		return Response.status(200).entity(temp).build();

	}// updateUser()
	
	@DELETE
    @Path("/{id}")
    public Response deleteUser(@PathParam("id") int id) throws URISyntaxException {
        Employee emp = DB.get(id);
        if(emp != null) {
            DB.remove(emp.getId());
            return Response.status(200).build();
        }
        return Response.status(404).build();
        
    }//deleteUser()

	// Dummy database
	static {

		Employee emp = new Employee();
		emp.setId(101);
		emp.setFirstName("Sudhanshu");
		emp.setLastName("Jha");
		emp.setUri("/user-management/1");

		Employee emp1 = new Employee();
		emp1.setId(102);
		emp1.setFirstName("Subham");
		emp1.setLastName("kumar");
		emp1.setUri("/user-management/2");

		Employee emp2 = new Employee();
		emp2.setId(103);
		emp2.setFirstName("Sivam");
		emp2.setLastName("Gupta");
		emp2.setUri("/user-management/3");

		DB.put(emp.getId(), emp);
		DB.put(emp1.getId(), emp1);
		DB.put(emp2.getId(), emp2);
	}

}// class
